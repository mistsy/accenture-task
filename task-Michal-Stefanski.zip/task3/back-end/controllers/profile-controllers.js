// GET
const getUserById = async (req, res, next) => {
	//
	// get profile
	//

	res.json({ profile });
};
